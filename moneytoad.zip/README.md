# BOXA Landingpage

```
npm install
```

```
npm start
```

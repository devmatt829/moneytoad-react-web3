export const BXNFT_ABI = require("../ABI/BXNFT.json");

export const BXNFT_CONTRACT = "0xced7c20e262be580c2b764a8a8aa51fce12e9630";
